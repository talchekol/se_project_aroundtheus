# Project 3: Around The U.S.

## Overview:

### Intro

### Figma

### features

### project description

### project conclustion
  
**Intro**
  
This project is made so all the elements are displayed correctly on popular screen sizes. This was my first project starting from scratch and also my first time that i am working with figma so it was fun and challenging.

* [link](https://talchekol.github.io/se_project_aroundtheus/) 

* [link] (https://tripleten.com/trainer/web/lesson/07e0bdf0-d597-4a8f-8dda-eada84722122/?from=program)

* [link] (https://drive.google.com/file/d/1enFnwm5rXoqIhgSAhMC63fXo_Wy08d3h/view?usp=sharing)

  
**Figma**  
  
* [Link to the project on Figma](https://www.figma.com/file/ii4xxsJ0ghevUOcssTlHZv/Sprint-3%3A-Around-the-US?node-id=0%3A1)  
  
**features**  
* Html
* css 
* figma
* responsive design
* grid layout
* media queries

**project description**

my assignment was tocreate an interactive page where users can add and 

remove photos, like photos of other users, and make a few minor adjustments to their own profile.


my biggest challenge was to design responsive page to each screen , and 

my solution was to use grid layout , even that was new to me and my 

first time using it in A project  i took this challenge beacuse i know 

it was  effective.


**project conclustion**

This was a good practice working with the new technology

that i learn like grid layout, media queries, figma design , i feel 

more cofidence dealing with that kind of projects.




