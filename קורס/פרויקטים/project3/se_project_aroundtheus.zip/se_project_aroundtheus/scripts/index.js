const initialCards = [
  {
    name: "Yosemite Valley",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/yosemite.jpg",
  },

  {
    name: "Lake Louise",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/lake-louise.jpg",
  },

  {
    name: "Bald Mountains",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/bald-mountains.jpg",
  },

  {
    name: "Latemar",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/latemar.jpg",
  },

  {
    name: "Vanoise National Park",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/vanoise.jpg",
  },

  {
    name: "Lago di Braies",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/around-project/lago.jpg",
  },
];

const profileEditBtb = document.querySelector("#profile-edit-btn");
const modelProfileEditWindow = document.querySelector("#profile-edit-model");
const modelCloseEdit = document.querySelector("#model-close-edit");
const profileTitleEdit = document.querySelector("#profile__title-js");
const profileDescriptionEdit = document.querySelector(
  "#profile__description-js"
);
const profileTitleInput = document.querySelector("#profile__Title-Input");
const profileDescriptionInput = document.querySelector(
  "#profile__Description-Input"
);

profileEditBtb.addEventListener("click", () => {
  profileTitleInput.value = profileTitleEdit.textContent;
  profileDescriptionInput.value = profileDescriptionEdit.textContent;
  modelProfileEditWindow.classList.add("model__opened");
});

modelCloseEdit.addEventListener("click", () => {
  modelProfileEditWindow.classList.remove("model__opened");
});
